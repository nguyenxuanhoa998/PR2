package Assignment06.Ex1;

public class TestShape {
    public static void main(String[] args) {
        Shape rec = new Rectangle("black" , 10 ,5 );
        System.out.println( rec);

        Shape p = new Triangle("yellow", 98, 20);
        System.out.println( p );


    }
}
