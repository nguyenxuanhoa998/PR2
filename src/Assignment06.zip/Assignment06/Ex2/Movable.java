package Assignment06.Ex2;

public interface Movable {
    void moveUp();
    void moveDown();
    void moveLeft();
    void moveRight();
    void Translate(int a, int b);

}
