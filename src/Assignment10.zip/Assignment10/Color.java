package Assignment10;

public enum Color {
    Blue, Red, Orange, Yellow, Purple

}
