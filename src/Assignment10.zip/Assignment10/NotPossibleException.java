package Assignment10;

public class NotPossibleException {


}
